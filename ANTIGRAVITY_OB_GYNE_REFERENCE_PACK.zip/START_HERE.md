# Antigravity OB-Gyne Reference Pack

This pack describes modifications to an EXISTING OB-Gyne / Obstetric History module.

1. Open the existing HIS project in Google Antigravity.
2. Extract this pack into a temporary project reference directory, such as `docs/ob_history_spec/`, or otherwise attach the materials so Gemini can read them.
3. Ask Gemini to read `ANTIGRAVITY_EXISTING_OB_GYNE_HISTORY_ENHANCEMENT.md` **in full**, plus `references/PC-2026-0016.pdf` and all seven screenshot references.
4. Paste the exact 'first message' in Section 16 of the main specification.
5. Require **Phase A (read-only audit and gap analysis)** first. Only approve Phase B once actual paths, schema impact and tests are reviewed.

Do not replace the existing module or run destructive migrations. The screenshots are examples; avoid using their contents as current patient data.
